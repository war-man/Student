# SchoolBuddy
Simple Demo Student Management App using SQLite
=========================================================
Calendar Dialog added.
