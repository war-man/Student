package com.example.faizan.studentmanagementapp.constants;

/**
 * Created by FAIZAN on 03-12-2016.
 */

public class AppConstants {
    public static final  String PREF="MY_PREF";
    public static final  String IS_LOGGEDIN="login";
}
