# StudentManagementApp
StudentManagementApp using Sqlite



LICENSE & privacy
------
https://github.com/junaidham/StudentManagementApp/blob/master/LICENSE

https://en.wikipedia.org/wiki/Apache_License

