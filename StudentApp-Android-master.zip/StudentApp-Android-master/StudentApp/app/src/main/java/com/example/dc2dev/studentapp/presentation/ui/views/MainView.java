package com.example.dc2dev.studentapp.presentation.ui.views;

/**
 * Created by dc2dev on 6/15/17.
 */

public interface MainView {
    void intenttocreatest();
    void intenttoupdatest(int pos);
    void deleteclicked(String pos);

}
